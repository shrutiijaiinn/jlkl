import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job

# Extract job parameters
args = getResolvedOptions(sys.argv, ["JOB_NAME"])

# Set up Spark and Glue contexts
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session

# Initialize the Glue Job
job = Job(glueContext)
job.init(args["JOB_NAME"], args)

# ----------------------------------------
# Load curated customer data from S3
# ----------------------------------------
customer_curated_df = glueContext.create_dynamic_frame.from_options(
    connection_type="s3",
    format="json",
    connection_options={
        "paths": ["s3://stedi-s3/customer/curated/"],
        "recurse": True
    },
    format_options={"multiline": False},
    transformation_ctx="customer_curated_df"
)

# ----------------------------------------
# Load raw Step Trainer records from S3
# ----------------------------------------
step_trainer_raw_df = glueContext.create_dynamic_frame.from_options(
    connection_type="s3",
    format="json",
    connection_options={
        "paths": ["s3://stedi-s3/step_trainer/landing/"],
        "recurse": True
    },
    format_options={"multiline": False},
    transformation_ctx="step_trainer_raw_df"
)

# ------------------------------------------------------
# Join Step Trainer data with customer data on serialNumber
# ------------------------------------------------------
linked_df = Join.apply(
    frame1=step_trainer_raw_df,
    frame2=customer_curated_df,
    keys1=["serialNumber"],
    keys2=["serialNumber"],
    transformation_ctx="linked_df"
)

# --------------------------------------------------
# Select only relevant fields for the trusted layer
# --------------------------------------------------
filtered_fields_df = ApplyMapping.apply(
    frame=linked_df,
    mappings=[
        ("sensorReadingTime", "long", "sensorReadingTime", "long"),
        ("serialNumber", "string", "serialNumber", "string"),
        ("distanceFromObject", "int", "distanceFromObject", "int"),
    ],
    transformation_ctx="filtered_fields_df"
)

# ---------------------------------------------------
# Store the filtered and trusted dataset to S3
# ---------------------------------------------------
glueContext.write_dynamic_frame.from_options(
    frame=filtered_fields_df,
    connection_type="s3",
    format="json",
    connection_options={
        "path": "s3://stedi-s3/step_trainer/trusted/",
        "compression": "snappy",
        "partitionKeys": []
    },
    transformation_ctx="trusted_output"
)

# Commit the job
job.commit()
