import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job

# Retrieve job arguments
args = getResolvedOptions(sys.argv, ["JOB_NAME"])

# Set up Glue and Spark contexts
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session

# Initialize the Glue job
job = Job(glueContext)
job.init(args["JOB_NAME"], args)

# ----------------------------------------
# Load Trusted Accelerometer Data from S3
# ----------------------------------------
accelerometer_trusted_df = glueContext.create_dynamic_frame.from_options(
    connection_type="s3",
    format="json",
    connection_options={
        "paths": ["s3://stedi-s3/accelerometer/trusted/"],
        "recurse": True
    },
    format_options={"multiline": False},
    transformation_ctx="accelerometer_trusted_df"
)

# --------------------------------------
# Load Trusted Step Trainer Data from S3
# --------------------------------------
step_trainer_trusted_df = glueContext.create_dynamic_frame.from_options(
    connection_type="s3",
    format="json",
    connection_options={
        "paths": ["s3://stedi-s3/step_trainer/trusted/"],
        "recurse": True
    },
    format_options={"multiline": False},
    transformation_ctx="step_trainer_trusted_df"
)

# -------------------------------------------------
# Join Step Trainer with Accelerometer Data on Time
# -------------------------------------------------
merged_data_df = Join.apply(
    frame1=step_trainer_trusted_df,
    frame2=accelerometer_trusted_df,
    keys1=["sensorReadingTime"],
    keys2=["timeStamp"],
    transformation_ctx="merged_data_df"
)

# -----------------------------------------
# Write Curated Dataset for ML to S3 Bucket
# -----------------------------------------
glueContext.write_dynamic_frame.from_options(
    frame=merged_data_df,
    connection_type="s3",
    format="json",
    connection_options={
        "path": "s3://stedi-s3/ML_curated/",
        "partitionKeys": []
    },
    transformation_ctx="curated_ml_data"
)

# Finalize the job
job.commit()
