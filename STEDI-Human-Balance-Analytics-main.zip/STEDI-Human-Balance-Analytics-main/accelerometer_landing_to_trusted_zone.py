import sys
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from awsglue.job import Job

# Extract the job name from arguments
args = getResolvedOptions(sys.argv, ["JOB_NAME"])

# Initialize Spark and Glue environments
sc = SparkContext()
glue_context = GlueContext(sc)
spark = glue_context.spark_session

# Set up the Glue job
job = Job(glue_context)
job.init(args["JOB_NAME"], args)

# -------------------------------------------------------------
# Read incoming accelerometer data from the landing zone in S3
# -------------------------------------------------------------
accel_raw_data = glue_context.create_dynamic_frame.from_options(
    connection_type="s3",
    format="json",
    connection_options={
        "paths": ["s3://stedi-s3/accelerometer/landing/"],
        "recurse": True
    },
    format_options={"multiline": False},
    transformation_ctx="accel_raw_data"
)

# -----------------------------------------------------------
# Load trusted customer records for identity verification
# -----------------------------------------------------------
verified_customers = glue_context.create_dynamic_frame.from_options(
    connection_type="s3",
    format="json",
    connection_options={
        "paths": ["s3://stedi-s3/customer/trusted/"],
        "recurse": True
    },
    format_options={"multiline": False},
    transformation_ctx="verified_customers"
)

# ----------------------------------------------------------------
# Match accelerometer records to valid customers using email & user
# ----------------------------------------------------------------
joined_data = Join.apply(
    frame1=accel_raw_data,
    frame2=verified_customers,
    keys1=["user"],
    keys2=["email"],
    transformation_ctx="joined_data"
)

# -----------------------------------------------------
# Select relevant fields and rename if necessary
# -----------------------------------------------------
sanitized_data = ApplyMapping.apply(
    frame=joined_data,
    mappings=[
        ("user", "string", "user", "string"),
        ("timeStamp", "long", "timeStamp", "long"),
        ("x", "double", "x", "float"),
        ("y", "double", "y", "float"),
        ("z", "double", "z", "float"),
    ],
    transformation_ctx="sanitized_data"
)

# ------------------------------------------------------------------
# Save the curated accelerometer data into the trusted S3 directory
# ------------------------------------------------------------------
glue_context.write_dynamic_frame.from_options(
    frame=sanitized_data,
    connection_type="s3",
    format="json",
    connection_options={
        "path": "s3://stedi-s3/accelerometer/trusted/",
        "partitionKeys": []
    },
    transformation_ctx="trusted_output"
)

# Finalize the job
job.commit()
