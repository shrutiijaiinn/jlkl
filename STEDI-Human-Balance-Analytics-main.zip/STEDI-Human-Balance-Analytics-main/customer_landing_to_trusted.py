import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job

# Fetch the job name from input arguments
args = getResolvedOptions(sys.argv, ["JOB_NAME"])

# Set up Spark and Glue environments
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session

# Initialize Glue job
job = Job(glueContext)
job.init(args["JOB_NAME"], args)

# ---------------------------------------------------------
# Load raw customer data stored in the S3 landing directory
# ---------------------------------------------------------
raw_customer_data = glueContext.create_dynamic_frame.from_options(
    connection_type="s3",
    format="json",
    connection_options={
        "paths": ["s3://stedi-s3/customer/landing/"],
        "recurse": True
    },
    format_options={"multiline": False},
    transformation_ctx="raw_customer_data"
)

# -------------------------------------------------------------
# Apply filter to select only users who agreed to data sharing
# -------------------------------------------------------------
filtered_customers = Filter.apply(
    frame=raw_customer_data,
    f=lambda record: record["shareWithResearchAsOfDate"] != 0,
    transformation_ctx="filtered_customers"
)

# --------------------------------------------------------
# Save the filtered customer data to the trusted S3 folder
# --------------------------------------------------------
glueContext.write_dynamic_frame.from_options(
    frame=filtered_customers,
    connection_type="s3",
    format="json",
    connection_options={
        "path": "s3://stedi-s3/customer/trusted/",
        "partitionKeys": []
    },
    transformation_ctx="write_trusted_customers"
)

# Complete the Glue job
job.commit()
