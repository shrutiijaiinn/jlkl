import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job

# Retrieve the job name from input arguments
args = getResolvedOptions(sys.argv, ["JOB_NAME"])

# Initialize Spark and Glue contexts
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session

# Start the Glue job
job = Job(glueContext)
job.init(args["JOB_NAME"], args)

# ---------------------------------------------------
# Load trusted customer dataset from S3 (JSON format)
# ---------------------------------------------------
trusted_customers_df = glueContext.create_dynamic_frame.from_options(
    connection_type="s3",
    format="json",
    connection_options={
        "paths": ["s3://stedi-s3/customer/trusted"],
        "recurse": True
    },
    format_options={"multiline": False},
    transformation_ctx="trusted_customers_df"
)

# -------------------------------------------------------
# Load raw accelerometer records from S3 landing location
# -------------------------------------------------------
raw_accelerometer_df = glueContext.create_dynamic_frame.from_options(
    connection_type="s3",
    format="json",
    connection_options={
        "paths": ["s3://stedi-s3/accelerometer/landing/"],
        "recurse": True
    },
    format_options={"multiline": False},
    transformation_ctx="raw_accelerometer_df"
)

# --------------------------------------------------------------------
# Join customer data with accelerometer data using email/user fields
# --------------------------------------------------------------------
filtered_customers_df = Join.apply(
    frame1=trusted_customers_df,
    frame2=raw_accelerometer_df,
    keys1=["email"],
    keys2=["user"],
    transformation_ctx="filtered_customers_df"
)

# ------------------------------------------------------------
# Retain only selected fields needed for the curated dataset
# ------------------------------------------------------------
selected_fields_df = ApplyMapping.apply(
    frame=filtered_customers_df,
    mappings=[
        ("serialNumber", "string", "serialNumber", "string"),
        ("shareWithPublicAsOfDate", "long", "shareWithPublicAsOfDate", "long"),
        ("birthDay", "string", "birthDay", "string"),
        ("registrationDate", "long", "registrationDate", "long"),
        ("shareWithResearchAsOfDate", "long", "shareWithResearchAsOfDate", "long"),
        ("customerName", "string", "customerName", "string"),
        ("email", "string", "email", "string"),
        ("lastUpdateDate", "long", "lastUpdateDate", "long"),
        ("phone", "string", "phone", "string"),
        ("shareWithFriendsAsOfDate", "long", "shareWithFriendsAsOfDate", "long"),
    ],
    transformation_ctx="selected_fields_df"
)

# --------------------------------------------------
# Write curated customer data back to S3 in JSON format
# --------------------------------------------------
glueContext.write_dynamic_frame.from_options(
    frame=selected_fields_df,
    connection_type="s3",
    format="json",
    connection_options={
        "path": "s3://stedi-s3/customer/curated/",
        "partitionKeys": []
    },
    transformation_ctx="curated_customer_output"
)

# Finalize the Glue job
job.commit()
